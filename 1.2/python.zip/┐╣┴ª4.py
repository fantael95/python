string= "hello"
n = 5

print(string*n) # hellohellohellohellohello


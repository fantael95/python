number1= 1
number2= number1 + 1
print(number1,number2) #1,2
    # 주석 만들기 컨트롤 + 슬래시
    
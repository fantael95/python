name=input("너의 이름은?")

print(name) # 이태영(입력한 값)

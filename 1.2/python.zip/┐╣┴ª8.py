list_variable=[]
list_variable.append(1)
list_variable.append("a")
list_variable[0]=0

print(list_variable) # [0, 'a']

age= int(input("너의 나이는?"))

print("올해나이:", age)
print("내년나이:", age+1) # 29 ,30 
string1= 'hello'
string2= string1
string3= 'world'+ +"!"

print(string2, "?" , string3) # hello ? world!

number1= 5
number2 = 10.0 + number1
number1 - 5
number3= number1 * (number2 + 10)

print(number1, number2, number3) # 5 15.0 125.0


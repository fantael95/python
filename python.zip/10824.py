A, B, C, D = map(str,input().split())
a = (A+B)
b = (C+D)
print(int(a)+int(b))
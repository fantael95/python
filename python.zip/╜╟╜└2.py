number1=int(input())
number2=int(input())
if number1 > number2 :
    print(number1)
elif number1 < number2 :
    print(number2)
elif number1 == number2 :
    print("false")
else :
    print("입력이 잘못되었습니다")
    
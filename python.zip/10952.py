i = 0
while i < 100 :
    a , b = map(int,input().split())
    if a == 0 and b == 0:
        break
    print(a+b)

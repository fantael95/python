number=int(input())
print(number>0)

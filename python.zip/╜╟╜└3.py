number=int(input())
print(1<number<10)
number=int(input())
if number > 0 and (number%2<1) :
    print("true")
else : 
    print("false")
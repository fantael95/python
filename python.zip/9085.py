T = int(input())
for t in range(1,T+1):
    N = int(input())
    number = map(int,input().split())
    print(sum(number))
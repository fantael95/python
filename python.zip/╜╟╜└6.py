string=input("문자열 입력 : ")
print(string[::-1])
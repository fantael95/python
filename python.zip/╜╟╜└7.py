a,b = map(int,input("입력 : ").split())

if a == b :
    print("False")

for i in range(a,b+1):
    if a == b :
        break
    count = 0
    print(i)



